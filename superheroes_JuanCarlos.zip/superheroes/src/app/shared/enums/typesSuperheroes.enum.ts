export enum TypesSuperheroes {
  SUPER_STRENGTH,
  CAN_FLY,
  NINJA,
  SOCIAL_SKILLS
}
